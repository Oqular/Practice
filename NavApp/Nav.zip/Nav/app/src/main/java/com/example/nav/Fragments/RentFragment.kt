package com.example.nav.Fragments


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.core.view.isVisible
import com.example.nav.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.fragment_rent.*

/**
 * A simple [Fragment] subclass.
 */
class RentFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val inf = inflater.inflate(R.layout.fragment_rent, container, false)
        //------------------------------------------------------------------------------------------
        //----------------------Show add button if logged in----------------------------------------
        val logged = activity!!.intent.getBooleanExtra("loggedIn", false)
        if (logged){
            val bttn: FloatingActionButton = inf.findViewById(R.id.addRentBtn)
            bttn.show()
        }
        //-------------------------------End of add button------------------------------------------





        return inf
    }



}
