package com.example.nav.Entities

import com.google.gson.annotations.SerializedName

class Types {
    @SerializedName("goodsId")
    var goodsId: Int? = null

    @SerializedName("typesId")
    var typesId: Int? = null

    @SerializedName("goods")
    var goods: ArrayList<Goods> = ArrayList()
}