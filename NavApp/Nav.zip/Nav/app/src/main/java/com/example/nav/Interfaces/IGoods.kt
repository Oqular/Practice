package com.example.nav.Interfaces


import com.example.nav.Entities.Goods
import com.example.nav.Entities.Login
import com.example.nav.Entities.User
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

interface IGoods {
    @GET("api/goods")
    fun getGoods(): Call<ArrayList<Goods>>

    @Multipart
    @POST("api/goods")
    fun postGoods(@Header("Authorization") authToken: String, @Part("goods") goods: Goods, @Part image: ArrayList<MultipartBody.Part>): Call<Goods>

    @POST("api/login")
    fun login(@Body loginInfo: Login): Call<User>

    @DELETE("api/goods/{id}")
    fun deleteGoods(@Path("id") id: Int, @Header("Authorization") authToken: String): Call<Goods>
}