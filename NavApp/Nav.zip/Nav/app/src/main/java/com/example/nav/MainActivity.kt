package com.example.nav

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat
import com.example.nav.Fragments.GoodsFragment
import com.example.nav.Fragments.RentFragment
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

//    lateinit var drawer: DrawerLayout
//    lateinit var toolbar: Toolbar
//    lateinit var navView: NavigationView
    var reg: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //-----------Access navigation header first before accessing its items------------
        val navHeader: View = navView.getHeaderView(0)
        val loginButton: Button = navHeader.findViewById(R.id.drawerLoginButton)
        loginButton.setOnClickListener { login() }

        val userMail: TextView = navHeader.findViewById(R.id.userMail)
        userMail.text = intent.getStringExtra("userName")
        userMail.visibility = View.VISIBLE

        val userinfo: TextView = navHeader.findViewById(R.id.userName)
        userinfo.text = intent.getStringExtra("userName")
        userinfo.visibility = View.VISIBLE
        //-------------------Navigation header work end-----------------------------------
        //-------------------------Show Login stuff if logged in------------------------
        val logged = intent.getBooleanExtra("loggedIn", false)
        if (logged){
//            addButton.visibility = View.INVISIBLE
            val menu: Menu = navView.menu
            val menuItem: MenuItem = menu.findItem(R.id.loginStuff)
            menuItem.isVisible = true
            loginButton.visibility = View.INVISIBLE
        }

        //---------------------------------End of login stuff---------------------------
        //Setting goods fragment as a main fragment that u see when u open the app
        if (savedInstanceState == null){
            val fragment = GoodsFragment()
            supportFragmentManager.beginTransaction().replace(R.id.fragmentFrame, fragment).commit()
        }
        //-----------------------------Drawer--------------------------------------------
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val drawer: DrawerLayout = findViewById(R.id.drawerLayout)
        val navView: NavigationView = findViewById(R.id.navView)

        val toggle = ActionBarDrawerToggle(this, drawer, toolbar, 0, 0)

        drawer.addDrawerListener(toggle)
        toggle.syncState()
        navView.setNavigationItemSelectedListener{
            when (it.itemId) {
                R.id.navGoods -> {
                    // handle click
                    Toast.makeText(this, "Goods", Toast.LENGTH_SHORT).show()
                    val fragment = GoodsFragment()
                    supportFragmentManager.beginTransaction().replace(R.id.fragmentFrame, fragment).commit()
                    drawer.closeDrawer(GravityCompat.START)
                    true
                }
                R.id.navRent -> {
                    Toast.makeText(this, "Rent", Toast.LENGTH_SHORT).show()
                    val fragment = RentFragment()
                    supportFragmentManager.beginTransaction().replace(R.id.fragmentFrame, fragment).commit()
                    drawer.closeDrawer(GravityCompat.START)
                    true
                }
                R.id.navServices -> {
                    it.isVisible = false

                    true
                }
                R.id.navLogOut -> {
                    intent.putExtra("userId", "")
                    intent.putExtra("userName", "")
                    intent.putExtra("Token", "")
                    intent.putExtra("loggedIn", false)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
        //---------------------------Drawer end------------------------------------------


    }

    private fun login(){
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }

    override fun onBackPressed() {
        //nothing
    }

    companion object {
        const val BaseUrl = "http://practiceshop.gearhostpreview.com"
        const val ImageTemp = "/funnyHa"
    }
}
