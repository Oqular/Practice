package com.example.nav.Entities

import com.google.gson.annotations.SerializedName

class Image {
    @SerializedName("id")
    var id: Int = 0

    @SerializedName("image")
    var imageB: String? = null
}