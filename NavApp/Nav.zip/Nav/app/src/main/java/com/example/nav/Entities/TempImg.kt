package com.example.nav.Entities

import android.graphics.Bitmap

class TempImg {
    var image: Bitmap? = null
    var path: String = ""
}