package com.example.nav

import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.PersistableBundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.nav.Adapters.TempImageListAdapter
import com.example.nav.Entities.Goods
import com.example.nav.Entities.TempImg
import com.example.nav.Entities.Types
import com.example.nav.Interfaces.IGoods
import com.example.nav.MainActivity.Companion.BaseUrl
import com.example.nav.MainActivity.Companion.ImageTemp
import kotlinx.android.synthetic.main.activity_goods_add.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URI
import java.util.*
import kotlin.collections.ArrayList

class GoodsAddActivity: AppCompatActivity() {

    var token: String = "Not set"
//    lateinit var con: String
    val imgArray: ArrayList<TempImg> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_goods_add)


        token = "Bearer " + intent.getStringExtra("Token")


        signAddImage.setOnClickListener { chooseImageToUpload() }
        if (imgArray != null)
            signGoods.setOnClickListener { postGoodsData() }//to be fixed
        else
            Toast.makeText(this, "Dont do that pls", Toast.LENGTH_SHORT).show()

    }
    private fun chooseImageToUpload(){
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1){
            if (data != null){
                val contentUri = data!!.data
//                con = contentUri!!.path!!
                try {
                    val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, contentUri)
                    val path = saveImage(bitmap)
//                    signImageList.setImageBitmap(bitmap)
                    val imgStuff = TempImg()
                    imgStuff.image = bitmap
                    imgStuff.path = path
                    imgArray.add(imgStuff)
//                    postGoodsData(imgStuff)
                    //-------------------------put images on display--------------------------------
                    var arrayAdapter = TempImageListAdapter(this, imgArray)

                    signImageList.adapter = arrayAdapter
                    //-------------------------end of display stuff---------------------------------
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                }
                catch (e: IOException){
                    Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }

    //saves image in to the phone storage so client get second copy of the image in his phone, might not be the best solution
    //to be resolved
    private fun saveImage(bitmap: Bitmap):String {
        val bytes = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes)
        val tempDirectory = File((Environment.getExternalStorageDirectory()).toString(), ImageTemp)
        if (!tempDirectory.exists())
        {
            tempDirectory.mkdirs()
        }
        try
        {
            val f = File(tempDirectory, ((Calendar.getInstance().timeInMillis).toString() + ".jpg"))
            f.createNewFile()
            val fos = FileOutputStream(f)
            fos.write(bytes.toByteArray())
            MediaScannerConnection.scanFile(this, arrayOf(f.path), arrayOf("image/jpeg"), null)
            fos.close()
            return f.absolutePath
        }
        catch (e: IOException) {
            e.printStackTrace()
        }
        return ""
    }

    private fun postGoodsData() {

        val types: ArrayList<Types> = ArrayList()
        val type = Types()
        type.typesId = 2

        types.add(type)
        val uId: Int = intent.getIntExtra("userId", -1)

        val goods = Goods()
        goods.title = signTitle.text.toString()
        goods.description   = signDescription.text.toString()
        goods.address = signAddress.text.toString()
        goods.phone = signPhone.text.toString()
        goods.seller = intent.getStringExtra("userName")
//        goods.userId = uId
        goods.type = types
        if (uId == -1){
            goods.userId = null
        }
        else{
            goods.userId = uId
        }


        //-----------------------------------------------------------------------------------------------------------------
        val retro = Retrofit.Builder().baseUrl(BaseUrl).addConverterFactory(GsonConverterFactory.create()).build()
        val service = retro.create(IGoods::class.java)

        val fileArray: ArrayList<File> = ArrayList()
        val imageArray: ArrayList<MultipartBody.Part> = ArrayList()
        for (i in imgArray){
            val file = File(i.path)
            val requestBody: RequestBody = RequestBody.create(MediaType.parse("multipart/form-data"), file)
            val imgFile: MultipartBody.Part = MultipartBody.Part.createFormData("images", file.name, requestBody)
            fileArray.add(file)
            imageArray.add(imgFile)
        }



//        val ii: ArrayList<MultipartBody.Part>
        val call: Call<Goods> = service.postGoods(token, goods, imageArray)
        call.enqueue(object: Callback<Goods> {
            override fun onResponse(call: Call<Goods>, response: Response<Goods>) {
                if (!response.isSuccessful){
                    Toast.makeText(this@GoodsAddActivity, "Code; " + response.code(), Toast.LENGTH_SHORT).show()
                    for (f in fileArray)
                        f.delete()
//                    file.delete()
                }
                else {
                    Toast.makeText(this@GoodsAddActivity, "Worked!! " + response.code(), Toast.LENGTH_SHORT).show()
//                    getGoodsData() do smth better
                    for (f in fileArray)
                        f.delete()
                    val intent2 = Intent(this@GoodsAddActivity, MainActivity::class.java)
                    intent2.putExtra("Token", intent.getStringExtra("Token"))
                    intent2.putExtra("userId", intent.getIntExtra("userId", -1))
                    intent2.putExtra("userName", intent.getStringExtra("userName"))
                    intent2.putExtra("loggedIn", true)
                    startActivity(intent2)
//                    file.delete()
                }
            }
            override fun onFailure(call: Call<Goods>, t: Throwable) {
                Toast.makeText(this@GoodsAddActivity, t.message, Toast.LENGTH_SHORT).show()
                for (f in fileArray)
                    f.delete()
//                file.delete()
            }

        })

    }
}