package com.example.nav.Fragments


import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.Toast
import com.example.nav.Adapters.GoodsListAdapter
import com.example.nav.Entities.Goods
import com.example.nav.Entities.TempImg
import com.example.nav.Entities.Types
import com.example.nav.GoodsAddActivity
import com.example.nav.GoodsDetailsActivity
import com.example.nav.Interfaces.IGoods
import com.example.nav.MainActivity
import com.example.nav.MainActivity.Companion.BaseUrl
import com.example.nav.R
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.fragment_goods.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList

/**
 * A simple [Fragment] subclass.
 */
class GoodsFragment : Fragment() {

    lateinit var contextF: Context
    var token: String = "Not set"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val inf = inflater.inflate(R.layout.fragment_goods, container, false)
        //------------------------------------------------------------------------------------------
        token = "Bearer " + activity!!.intent.getStringExtra("Token")
        //----------------------Show add button if logged in----------------------------------------
        val logged = activity!!.intent.getBooleanExtra("loggedIn", false)
        if (logged){
            val addButton: FloatingActionButton = inf.findViewById(R.id.addGoodsBtn)
            addButton.show()
            addButton.setOnClickListener{ openAddingActivity() }
        }
        //-------------------------------End of add button------------------------------------------

        contextF = container!!.context
        getGoodsData()
        val listG: ListView = inf.findViewById(R.id.listGoods)

        //-------------------------------Delete item on holding-------------------------------------
        listG.setOnItemLongClickListener { _, _, position, _ ->
            val item: Goods = listG.getItemAtPosition(position) as Goods
            Toast.makeText(activity, item.id.toString(), Toast.LENGTH_SHORT).show()
            //--------------------------
            val retro = Retrofit.Builder().baseUrl(BaseUrl).addConverterFactory(GsonConverterFactory.create()).build()
            val service = retro.create(IGoods::class.java)
            val call =  service.deleteGoods(item.id, token)
            call.enqueue(object : Callback<Goods> {
                override fun onResponse(call: Call<Goods>, response: Response<Goods>) {
                    if (response.code() == 200) {
                        Toast.makeText(activity, "Worked :)", Toast.LENGTH_SHORT).show()
                        getGoodsData()
                    }
                    else{
                        Toast.makeText(activity, "No Good :( "  + response.code().toString(), Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<Goods>, t: Throwable) {
                }
            })
            true
        }
        //-------------------------------End of item deletion---------------------------------------

        listG.setOnItemClickListener { parent, view, position, id ->
            val intent = Intent(activity, GoodsDetailsActivity::class.java)
            startActivity(intent)
        }

        return inf
    }



    private fun openAddingActivity() {
        val intent = Intent(activity, GoodsAddActivity::class.java)
        intent.putExtra("Token", activity!!.intent.getStringExtra("Token"))
        intent.putExtra("userId", activity!!.intent.getIntExtra("userId", -1))
        intent.putExtra("userName", activity!!.intent.getStringExtra("userName"))
        intent.putExtra("loggedIn", true)

        startActivity(intent)
    }

    private fun getGoodsData() {
        val retro = Retrofit.Builder().baseUrl(BaseUrl).addConverterFactory(GsonConverterFactory.create()).build()
        val service = retro.create(IGoods::class.java)
        val call =  service.getGoods()
        call.enqueue(object : Callback<ArrayList<Goods>> {
            override fun onResponse(call: Call<ArrayList<Goods>>, response: Response<ArrayList<Goods>>) {
                if (response.code() == 200) {
                    val resp = response.body()!!

                    val arrayAdapter = GoodsListAdapter(contextF, resp)

                    listGoods.adapter = arrayAdapter
                }
            }
            override fun onFailure(call: Call<ArrayList<Goods>>, t: Throwable) {
            }
        })
    }

}
