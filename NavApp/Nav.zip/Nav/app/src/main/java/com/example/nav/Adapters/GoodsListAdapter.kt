package com.example.nav.Adapters

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.nav.Entities.Goods
import com.example.nav.R

class GoodsListAdapter(private val context: Context, private val imgArray: ArrayList<Goods>) : BaseAdapter() {
    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return imgArray.size
    }

    override fun getItem(position: Int): Any {
        return imgArray[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val rowV = inflater.inflate(R.layout.goods_list_row, parent, false)
        val textV = rowV.findViewById(R.id.goodsTxt) as TextView
        val imageV = rowV.findViewById(R.id.goodsImg) as ImageView
        val item = getItem(position) as Goods
        textV.text = item.title
        if (item.images.size != 0) {
            val img: ByteArray = Base64.decode(item.images[0].imageB, 0)//--------
            val bitmap: Bitmap = BitmapFactory.decodeByteArray(img, 0, img.size, BitmapFactory.Options())//-------
            imageV.setImageBitmap(bitmap)
        }
        return rowV
    }
}