package com.example.nav.Adapters

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.nav.Entities.Goods
import com.example.nav.Entities.TempImg
import com.example.nav.R

class TempImageListAdapter(context: Context, private val imgArray: ArrayList<TempImg>) : BaseAdapter() {
    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return imgArray.size
    }

    override fun getItem(position: Int): Any {
        return imgArray[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val rowV = inflater.inflate(R.layout.image_list_row, parent, false)
        val imageV = rowV.findViewById(R.id.imageItem) as ImageView
        val item = getItem(position) as TempImg
        imageV.setImageBitmap(item.image)
        return rowV
    }
}